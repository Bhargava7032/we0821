const particleField = document.querySelector(".page2-particles");

if (particleField) {
  const particleCount = window.matchMedia("(max-width: 700px)").matches ? 10 : 18;

  for (let index = 0; index < particleCount; index += 1) {
    const particle = document.createElement("span");
    const isHeart = index % 4 === 0;

    particle.className = isHeart ? "page2-particle page2-particle--heart" : "page2-particle";
    particle.setAttribute("aria-hidden", "true");
    if (isHeart) particle.textContent = "♥";

    particle.style.left = `${Math.random() * 100}%`;
    particle.style.setProperty("--size", isHeart ? `${9 + Math.random() * 10}px` : `${2 + Math.random() * 3}px`);
    particle.style.setProperty("--duration", `${15 + Math.random() * 12}s`);
    particle.style.setProperty("--delay", `${-Math.random() * 22}s`);
    particle.style.setProperty("--drift", `${Math.round(Math.random() * 64 - 32)}px`);
    particleField.append(particle);
  }
}

