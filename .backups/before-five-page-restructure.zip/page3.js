const page3Particles = document.querySelector(".page3-particles");

if (page3Particles) {
  for (let index = 0; index < 18; index += 1) {
    const particle = document.createElement("span");
    const isHeart = index % 4 === 0;

    particle.className = isHeart ? "page3-particle page3-particle--heart" : "page3-particle";
    particle.setAttribute("aria-hidden", "true");
    if (isHeart) particle.textContent = "♥";
    particle.style.left = `${Math.random() * 100}%`;
    particle.style.setProperty("--size", isHeart ? `${9 + Math.random() * 9}px` : `${2 + Math.random() * 3}px`);
    particle.style.setProperty("--duration", `${17 + Math.random() * 13}s`);
    particle.style.setProperty("--delay", `${-Math.random() * 24}s`);
    particle.style.setProperty("--drift", `${Math.round(Math.random() * 56 - 28)}px`);
    page3Particles.append(particle);
  }
}

