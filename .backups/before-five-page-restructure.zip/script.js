const particleField = document.querySelector(".particles");

if (particleField) {
  const particleCount = window.matchMedia("(max-width: 600px)").matches ? 16 : 26;

  for (let index = 0; index < particleCount; index += 1) {
    const particle = document.createElement("span");
    const isHeart = index % 6 === 0;

    particle.className = isHeart ? "particle particle--heart" : "particle";
    particle.setAttribute("aria-hidden", "true");
    if (isHeart) particle.textContent = "♥";

    particle.style.left = `${Math.random() * 100}%`;
    particle.style.setProperty("--size", isHeart ? `${8 + Math.random() * 8}px` : `${2 + Math.random() * 3}px`);
    particle.style.setProperty("--duration", `${12 + Math.random() * 14}s`);
    particle.style.setProperty("--delay", `${-Math.random() * 24}s`);
    particle.style.setProperty("--drift", `${Math.round(Math.random() * 100 - 50)}px`);
    particle.style.setProperty("--opacity", `${0.25 + Math.random() * 0.45}`);

    particleField.append(particle);
  }
}

