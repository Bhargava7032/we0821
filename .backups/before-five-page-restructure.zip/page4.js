const page4Particles = document.querySelector(".page4-particles");

if (page4Particles) {
  const particleCount = window.matchMedia("(max-width: 700px)").matches ? 10 : 18;

  for (let index = 0; index < particleCount; index += 1) {
    const particle = document.createElement("span");
    const isHeart = index % 4 === 0;

    particle.className = isHeart ? "page4-particle page4-particle--heart" : "page4-particle";
    particle.setAttribute("aria-hidden", "true");
    if (isHeart) particle.textContent = "♥";

    particle.style.left = `${Math.random() * 100}%`;
    particle.style.setProperty("--size", isHeart ? `${9 + Math.random() * 8}px` : `${2 + Math.random() * 3}px`);
    particle.style.setProperty("--duration", `${17 + Math.random() * 13}s`);
    particle.style.setProperty("--delay", `${-Math.random() * 24}s`);
    particle.style.setProperty("--drift", `${Math.round(Math.random() * 54 - 27)}px`);
    page4Particles.append(particle);
  }
}

