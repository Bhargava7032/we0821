const page10Particles = document.querySelector(".page10-particles");
const page10Proposal = document.querySelector(".page10-proposal");
const page10Celebration = document.querySelector(".page10-celebration");
const page10CelebrationTitle = document.querySelector("#page10-celebration-title");
const page10Effects = document.querySelector(".page10-celebration-effects");
const page10Yes = document.querySelector(".page10-yes");
const page10No = document.querySelector(".page10-no");
const page10NoMessage = document.querySelector(".page10-no-message");

if (page10Particles) {
  const particleCount = window.matchMedia("(max-width: 700px)").matches ? 12 : 22;

  for (let index = 0; index < particleCount; index += 1) {
    const particle = document.createElement("span");
    const isHeart = index % 5 === 0;
    particle.className = isHeart ? "page10-particle page10-particle--heart" : "page10-particle";
    particle.setAttribute("aria-hidden", "true");
    if (isHeart) particle.textContent = "♥";
    particle.style.left = `${Math.random() * 100}%`;
    particle.style.setProperty("--size", isHeart ? `${9 + Math.random() * 8}px` : `${2 + Math.random() * 3}px`);
    particle.style.setProperty("--duration", `${16 + Math.random() * 14}s`);
    particle.style.setProperty("--delay", `${-Math.random() * 24}s`);
    particle.style.setProperty("--drift", `${Math.round(Math.random() * 64 - 32)}px`);
    page10Particles.append(particle);
  }
}

function createCelebrationEffects() {
  if (!page10Effects) return;

  for (let index = 0; index < 34; index += 1) {
    const particle = document.createElement("span");
    const isHeart = index % 3 === 0;
    const isPetal = !isHeart && index % 2 === 0;
    particle.className = `page10-celebration-particle${isHeart ? " page10-particle--heart" : ""}${isPetal ? " page10-celebration-particle--petal" : ""}`;
    particle.setAttribute("aria-hidden", "true");
    if (isHeart) particle.textContent = "♥";
    particle.style.setProperty("--left", `${Math.random() * 100}%`);
    particle.style.setProperty("--size", `${12 + Math.random() * 20}px`);
    particle.style.setProperty("--duration", `${3.8 + Math.random() * 3.8}s`);
    particle.style.setProperty("--delay", `${Math.random() * 1.4}s`);
    page10Effects.append(particle);
  }

  for (const [left, top, delay] of [["19%", "24%", ".15s"], ["78%", "31%", ".45s"], ["50%", "15%", ".75s"]]) {
    const burst = document.createElement("span");
    burst.className = "page10-firework";
    burst.setAttribute("aria-hidden", "true");
    burst.style.setProperty("--left", left);
    burst.style.setProperty("--top", top);

    for (let ray = 0; ray < 12; ray += 1) {
      const spark = document.createElement("i");
      spark.style.setProperty("--angle", `${ray * 30}deg`);
      spark.style.setProperty("--delay", delay);
      burst.append(spark);
    }

    page10Effects.append(burst);
  }
}

page10No?.addEventListener("click", () => {
  if (!page10NoMessage) return;
  const shouldShow = page10NoMessage.hidden;
  page10NoMessage.hidden = !shouldShow;
  page10No.setAttribute("aria-expanded", String(shouldShow));
});

page10Yes?.addEventListener("click", () => {
  if (!page10Proposal || !page10Celebration || page10Yes.disabled) return;
  page10Yes.disabled = true;
  page10No && (page10No.disabled = true);
  page10Proposal.classList.add("is-leaving");
  window.setTimeout(() => {
    page10Proposal.hidden = true;
    page10Celebration.hidden = false;
    createCelebrationEffects();
    window.requestAnimationFrame(() => {
      page10Celebration.classList.add("is-visible");
      page10CelebrationTitle?.focus({ preventScroll: true });
    });
  }, 460);
});
